/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../sudoku_mk10-dev/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[50];
    char stringdata0[1014];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 20), // "on_newButton_clicked"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 10), // "pushButton"
QT_MOC_LITERAL(4, 44, 3), // "num"
QT_MOC_LITERAL(5, 48, 20), // "on_oneButton_clicked"
QT_MOC_LITERAL(6, 69, 20), // "on_twoButton_clicked"
QT_MOC_LITERAL(7, 90, 22), // "on_threeButton_clicked"
QT_MOC_LITERAL(8, 113, 21), // "on_fourButton_clicked"
QT_MOC_LITERAL(9, 135, 21), // "on_fiveButton_clicked"
QT_MOC_LITERAL(10, 157, 20), // "on_sixButton_clicked"
QT_MOC_LITERAL(11, 178, 22), // "on_sevenButton_clicked"
QT_MOC_LITERAL(12, 201, 22), // "on_eightButton_clicked"
QT_MOC_LITERAL(13, 224, 21), // "on_nineButton_clicked"
QT_MOC_LITERAL(14, 246, 22), // "on_clearButton_clicked"
QT_MOC_LITERAL(15, 269, 22), // "on_checkButton_clicked"
QT_MOC_LITERAL(16, 292, 21), // "on_hintButton_clicked"
QT_MOC_LITERAL(17, 314, 29), // "on_sudokuWidget_doubleClicked"
QT_MOC_LITERAL(18, 344, 5), // "index"
QT_MOC_LITERAL(19, 350, 31), // "on_hardLevelSlider_valueChanged"
QT_MOC_LITERAL(20, 382, 5), // "value"
QT_MOC_LITERAL(21, 388, 12), // "insertNumber"
QT_MOC_LITERAL(22, 401, 6), // "before"
QT_MOC_LITERAL(23, 408, 5), // "after"
QT_MOC_LITERAL(24, 414, 15), // "insertNumber_16"
QT_MOC_LITERAL(25, 430, 13), // "pushButton_16"
QT_MOC_LITERAL(26, 444, 23), // "on_oneButton_16_clicked"
QT_MOC_LITERAL(27, 468, 23), // "on_twoButton_16_clicked"
QT_MOC_LITERAL(28, 492, 25), // "on_threeButton_16_clicked"
QT_MOC_LITERAL(29, 518, 24), // "on_fourButton_16_clicked"
QT_MOC_LITERAL(30, 543, 24), // "on_fiveButton_16_clicked"
QT_MOC_LITERAL(31, 568, 23), // "on_sixButton_16_clicked"
QT_MOC_LITERAL(32, 592, 25), // "on_sevenButton_16_clicked"
QT_MOC_LITERAL(33, 618, 25), // "on_eightButton_16_clicked"
QT_MOC_LITERAL(34, 644, 24), // "on_nineButton_16_clicked"
QT_MOC_LITERAL(35, 669, 23), // "on_tenButton_16_clicked"
QT_MOC_LITERAL(36, 693, 26), // "on_elevenButton_16_clicked"
QT_MOC_LITERAL(37, 720, 26), // "on_twelveButton_16_clicked"
QT_MOC_LITERAL(38, 747, 28), // "on_thirteenButton_16_clicked"
QT_MOC_LITERAL(39, 776, 28), // "on_fourteenButton_16_clicked"
QT_MOC_LITERAL(40, 805, 27), // "on_fifteenButton_16_clicked"
QT_MOC_LITERAL(41, 833, 27), // "on_sixteenButton_16_clicked"
QT_MOC_LITERAL(42, 861, 14), // "nineSudokuSave"
QT_MOC_LITERAL(43, 876, 14), // "nineSudokuLoad"
QT_MOC_LITERAL(44, 891, 17), // "sixteenSudokuSave"
QT_MOC_LITERAL(45, 909, 17), // "sixteenSudokuLoad"
QT_MOC_LITERAL(46, 927, 21), // "on_saveButton_clicked"
QT_MOC_LITERAL(47, 949, 21), // "on_loadButton_clicked"
QT_MOC_LITERAL(48, 971, 20), // "on_newButton_pressed"
QT_MOC_LITERAL(49, 992, 21) // "on_newButton_released"

    },
    "MainWindow\0on_newButton_clicked\0\0"
    "pushButton\0num\0on_oneButton_clicked\0"
    "on_twoButton_clicked\0on_threeButton_clicked\0"
    "on_fourButton_clicked\0on_fiveButton_clicked\0"
    "on_sixButton_clicked\0on_sevenButton_clicked\0"
    "on_eightButton_clicked\0on_nineButton_clicked\0"
    "on_clearButton_clicked\0on_checkButton_clicked\0"
    "on_hintButton_clicked\0"
    "on_sudokuWidget_doubleClicked\0index\0"
    "on_hardLevelSlider_valueChanged\0value\0"
    "insertNumber\0before\0after\0insertNumber_16\0"
    "pushButton_16\0on_oneButton_16_clicked\0"
    "on_twoButton_16_clicked\0"
    "on_threeButton_16_clicked\0"
    "on_fourButton_16_clicked\0"
    "on_fiveButton_16_clicked\0"
    "on_sixButton_16_clicked\0"
    "on_sevenButton_16_clicked\0"
    "on_eightButton_16_clicked\0"
    "on_nineButton_16_clicked\0"
    "on_tenButton_16_clicked\0"
    "on_elevenButton_16_clicked\0"
    "on_twelveButton_16_clicked\0"
    "on_thirteenButton_16_clicked\0"
    "on_fourteenButton_16_clicked\0"
    "on_fifteenButton_16_clicked\0"
    "on_sixteenButton_16_clicked\0nineSudokuSave\0"
    "nineSudokuLoad\0sixteenSudokuSave\0"
    "sixteenSudokuLoad\0on_saveButton_clicked\0"
    "on_loadButton_clicked\0on_newButton_pressed\0"
    "on_newButton_released"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      43,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  229,    2, 0x08 /* Private */,
       3,    1,  230,    2, 0x08 /* Private */,
       5,    0,  233,    2, 0x08 /* Private */,
       6,    0,  234,    2, 0x08 /* Private */,
       7,    0,  235,    2, 0x08 /* Private */,
       8,    0,  236,    2, 0x08 /* Private */,
       9,    0,  237,    2, 0x08 /* Private */,
      10,    0,  238,    2, 0x08 /* Private */,
      11,    0,  239,    2, 0x08 /* Private */,
      12,    0,  240,    2, 0x08 /* Private */,
      13,    0,  241,    2, 0x08 /* Private */,
      14,    0,  242,    2, 0x08 /* Private */,
      15,    0,  243,    2, 0x08 /* Private */,
      16,    0,  244,    2, 0x08 /* Private */,
      17,    1,  245,    2, 0x08 /* Private */,
      19,    1,  248,    2, 0x08 /* Private */,
      21,    2,  251,    2, 0x08 /* Private */,
      24,    2,  256,    2, 0x08 /* Private */,
      25,    1,  261,    2, 0x08 /* Private */,
      26,    0,  264,    2, 0x08 /* Private */,
      27,    0,  265,    2, 0x08 /* Private */,
      28,    0,  266,    2, 0x08 /* Private */,
      29,    0,  267,    2, 0x08 /* Private */,
      30,    0,  268,    2, 0x08 /* Private */,
      31,    0,  269,    2, 0x08 /* Private */,
      32,    0,  270,    2, 0x08 /* Private */,
      33,    0,  271,    2, 0x08 /* Private */,
      34,    0,  272,    2, 0x08 /* Private */,
      35,    0,  273,    2, 0x08 /* Private */,
      36,    0,  274,    2, 0x08 /* Private */,
      37,    0,  275,    2, 0x08 /* Private */,
      38,    0,  276,    2, 0x08 /* Private */,
      39,    0,  277,    2, 0x08 /* Private */,
      40,    0,  278,    2, 0x08 /* Private */,
      41,    0,  279,    2, 0x08 /* Private */,
      42,    0,  280,    2, 0x08 /* Private */,
      43,    0,  281,    2, 0x08 /* Private */,
      44,    0,  282,    2, 0x08 /* Private */,
      45,    0,  283,    2, 0x08 /* Private */,
      46,    0,  284,    2, 0x08 /* Private */,
      47,    0,  285,    2, 0x08 /* Private */,
      48,    0,  286,    2, 0x08 /* Private */,
      49,    0,  287,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,   18,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   22,   23,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   22,   23,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_newButton_clicked(); break;
        case 1: _t->pushButton((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_oneButton_clicked(); break;
        case 3: _t->on_twoButton_clicked(); break;
        case 4: _t->on_threeButton_clicked(); break;
        case 5: _t->on_fourButton_clicked(); break;
        case 6: _t->on_fiveButton_clicked(); break;
        case 7: _t->on_sixButton_clicked(); break;
        case 8: _t->on_sevenButton_clicked(); break;
        case 9: _t->on_eightButton_clicked(); break;
        case 10: _t->on_nineButton_clicked(); break;
        case 11: _t->on_clearButton_clicked(); break;
        case 12: _t->on_checkButton_clicked(); break;
        case 13: _t->on_hintButton_clicked(); break;
        case 14: _t->on_sudokuWidget_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 15: _t->on_hardLevelSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->insertNumber((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 17: _t->insertNumber_16((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 18: _t->pushButton_16((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_oneButton_16_clicked(); break;
        case 20: _t->on_twoButton_16_clicked(); break;
        case 21: _t->on_threeButton_16_clicked(); break;
        case 22: _t->on_fourButton_16_clicked(); break;
        case 23: _t->on_fiveButton_16_clicked(); break;
        case 24: _t->on_sixButton_16_clicked(); break;
        case 25: _t->on_sevenButton_16_clicked(); break;
        case 26: _t->on_eightButton_16_clicked(); break;
        case 27: _t->on_nineButton_16_clicked(); break;
        case 28: _t->on_tenButton_16_clicked(); break;
        case 29: _t->on_elevenButton_16_clicked(); break;
        case 30: _t->on_twelveButton_16_clicked(); break;
        case 31: _t->on_thirteenButton_16_clicked(); break;
        case 32: _t->on_fourteenButton_16_clicked(); break;
        case 33: _t->on_fifteenButton_16_clicked(); break;
        case 34: _t->on_sixteenButton_16_clicked(); break;
        case 35: { int _r = _t->nineSudokuSave();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 36: { int _r = _t->nineSudokuLoad();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 37: { int _r = _t->sixteenSudokuSave();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 38: { int _r = _t->sixteenSudokuLoad();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 39: _t->on_saveButton_clicked(); break;
        case 40: _t->on_loadButton_clicked(); break;
        case 41: _t->on_newButton_pressed(); break;
        case 42: _t->on_newButton_released(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 43)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 43;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 43)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 43;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
